/**
 * An example Ant-based Java project.
 */
package sample.java.project;
