package com.poc.vo;

import java.io.Serializable;

public class SearchPicsVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String number;

	private int year;

	private String type;

	private String category;

	private boolean userFlag = false;

	private String ssrNumber;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isUserFlag() {
		return userFlag;
	}

	public void setUserFlag(boolean userFlag) {
		this.userFlag = userFlag;
	}

	public String getSsrNumber() {
		return ssrNumber;
	}

	public void setSsrNumber(String ssrNumber) {
		this.ssrNumber = ssrNumber;
	}

}
