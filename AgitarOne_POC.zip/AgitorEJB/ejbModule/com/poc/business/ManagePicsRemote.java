package com.poc.business;

import java.util.List;

import com.poc.vo.SearchPicsVO;

public interface ManagePicsRemote {

	public List<SearchPicsVO> searchPics(SearchPicsVO searchPicsVO);
}
