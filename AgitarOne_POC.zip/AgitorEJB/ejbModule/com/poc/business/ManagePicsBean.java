package com.poc.business;

import java.util.List;

import com.poc.persistence.ManagePicsPersistenceBean;
import com.poc.vo.SearchPicsVO;

public class ManagePicsBean implements ManagePicsRemote {

	ManagePicsPersistenceBean persistence;

	@Override
	public List<SearchPicsVO> searchPics(SearchPicsVO searchPicsVO) {
		persistence = new ManagePicsPersistenceBean();
		List<SearchPicsVO> picList = persistence.selectPics(searchPicsVO);
		return picList;
	}

}
