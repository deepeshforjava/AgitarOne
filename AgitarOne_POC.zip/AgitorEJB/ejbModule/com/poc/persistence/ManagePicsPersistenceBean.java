package com.poc.persistence;

import java.util.List;

import com.poc.persistence.dao.ManagePicsDAO;
import com.poc.vo.SearchPicsVO;

public class ManagePicsPersistenceBean implements ManagePicsPersistence {

	ManagePicsDAO picsDAO;

	@Override
	public List<SearchPicsVO> selectPics(SearchPicsVO searchVO) {
		picsDAO = new ManagePicsDAO();
		return picsDAO.selectPics(searchVO);
	}

}
