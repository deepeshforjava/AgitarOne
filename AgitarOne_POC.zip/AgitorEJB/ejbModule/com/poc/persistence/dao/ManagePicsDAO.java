package com.poc.persistence.dao;

import java.util.ArrayList;
import java.util.List;

import com.poc.vo.SearchPicsVO;

public class ManagePicsDAO {

	public List<SearchPicsVO> selectPics(SearchPicsVO searchVO) {

		List<SearchPicsVO> list = new ArrayList<SearchPicsVO>();

		SearchPicsVO searchPicVO = new SearchPicsVO();
		searchPicVO.setCategory("Test");
		searchPicVO.setNumber("8787");
		searchPicVO.setType("Test Type");
		searchPicVO.setUserFlag(true);
		searchPicVO.setYear(1998);
		list.add(searchPicVO);
		return list;

	}

}
