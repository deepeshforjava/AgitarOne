package com.poc.persistence;

import java.util.List;

import com.poc.vo.SearchPicsVO;

public interface ManagePicsPersistence {

	public List<SearchPicsVO> selectPics(SearchPicsVO searchVO);

}
