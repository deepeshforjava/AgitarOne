package com.poc;

public class DemoClass {
	private int x;


	public static void main(String[] args) {
		DemoClass dc = new DemoClass();
		dc.overloadTester();
	}
	
	public DemoClass() {
		// assign default value
		x = 0;
	}


	public DemoClass(int x) {
		// use this.x to refer to the instance variable x
		// use x to refer to a local variable x (more specifically,
		// method parameter x)
		this.x = x;
	}

	public DemoClass(DemoClass otherDemo) {
		// copy the value from the otherDemo
		this.x = otherDemo.x;
	}

	// static method (aka class method)
	public static void s1() {
		return;
	}

	// instance method
	public void i1() {
		return;
	}

	public static void s2() {
		// i1(); // compile-time error
		s1(); // DemoClass.s1
		return;
	}

	// instance calling static OK
	// instance calling instance OK
	public void i2() {
		s1(); // DemoClass.s1();
		i1(); // this.i1();
		return;
	}

	// call various versions of overload() based on their
	// list of parameters (aka function signatures)
	public static void overloadTester() {
		System.out.println("overloadTester:\n");

		overload((byte) 1);
		//overload((short) 1);
		overload(1);
		overload(1L);
		overload(1.0f);
		overload(1.0);
		overload('1');
		overload(true);
		overload("Test");
	}

	public static void overload(String s) {
		System.out.println("String");
	}

	
	public static void overload(byte b) {
		System.out.println("byte");
	}

	public static void overload(short s) {
		System.out.println("short");
	}

	public static void overload(int i) {
		System.out.println("int");
	}

	public static void overload(long l) {
		System.out.println("long");
	}

	public static void overload(float f) {
		System.out.println("float");
	}

	public static void overload(double d) {
		System.out.println("double");
	}

	public static void overload(char c) {
		System.out.println("char");
	}

	public static void overload(boolean b) {
		System.out.println("boolean");
	}
}