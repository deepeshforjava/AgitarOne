package com.poc;

public class TestAgitor {

	public static void main(String[] args) {

		String inputStr = "Hexaware:Tech:Inc";

		String[] strArr = getStrArr(inputStr);

		printStringArr(strArr);
	}

	static String[] getStrArr(String str) {
		String[] s = str.split(":");
		return s;
	}

	private static void printStringArr(String[] strArr) {
		for (String value : strArr) {
			System.out.println("String Array Value: " + value);
		}
	}

}
