package com.hexa.poc.common.bean;


import java.io.Serializable;

public class BaseManagedBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String counterPartyId;

	
	
	
	public void getAvailablePics() {
		
		
		
	}
	
	
	
	
}
