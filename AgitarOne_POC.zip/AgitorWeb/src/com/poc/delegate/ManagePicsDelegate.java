package com.poc.delegate;

import java.util.ArrayList;
import java.util.List;

import com.poc.business.ManagePicsRemote;
import com.poc.vo.SearchPicsVO;

public class ManagePicsDelegate {

	ManagePicsRemote remote;

	public ManagePicsDelegate() {

	}

	public List<SearchPicsVO> searchPics(SearchPicsVO searchVO) {

		List<SearchPicsVO> picList = new ArrayList<SearchPicsVO>();

		remote.searchPics(searchVO);

		return picList;
	}

}
