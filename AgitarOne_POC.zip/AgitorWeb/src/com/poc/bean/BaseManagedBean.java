package com.poc.bean;

import java.io.Serializable;

import com.poc.delegate.ManagePicsDelegate;
import com.poc.vo.SearchPicsVO;

public class BaseManagedBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String counterPartyId;

	private ManagePicsDelegate picDelegate = null;

	public void getAvailablePics() {

		picDelegate = new ManagePicsDelegate();
		SearchPicsVO searchVO = new SearchPicsVO();

		String ssrNumber = "708";
		int fiscalYear = 1996;

		try {
			if (ssrNumber == null || ssrNumber.isEmpty()) {
				System.out.println("SSR Number is Either Empty or Null...");
				return;
			}
			if (fiscalYear == 0) {
				System.out.println("Fiscal Year is Invalid...");
				return;
			}

			searchVO.setSsrNumber(ssrNumber);
			searchVO.setYear(fiscalYear);

		} catch (Exception ex) {
			System.err.println("Exception: " + ex);
		}
	}

}
